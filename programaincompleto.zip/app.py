from flask import Flask, render_template, request, redirect, url_for
from pymongo import MongoClient
from bson.objectid import ObjectId
from datetime import datetime

app = Flask(__name__)

# Configuración de la conexión a MongoDB
client = MongoClient("mongodb://localhost:27017/")  # URL de conexión (ajustar si es Atlas u otro host)
db = client["banquetes_catherine"]                  # Nombre de la base de datos
clientes_coll = db["clientes"]
eventos_coll = db["eventos"]
empleados_coll = db["empleados"]
notifs_coll   = db["notificaciones"]  # colección de notificaciones (opcional)

# Ruta 1: Página de inicio
@app.route("/")
def home():
    return render_template("home.html")

# Ruta 2: Formulario de nuevo pedido (mostrar formulario)
@app.route("/nuevo", methods=["GET"])
def nuevo_evento_form():
    return render_template("order.html")

# Ruta 3: Procesar datos del nuevo evento (pedido)
@app.route("/nuevo", methods=["POST"])
def nuevo_evento_submit():
    # Obtener datos del formulario
    nombre_cliente = request.form.get("nombre")
    contacto = request.form.get("contacto")
    fecha_evento = request.form.get("fecha")
    invitados = int(request.form.get("invitados"))
    tipo_menu = request.form.get("menu")
    req_especiales = request.form.get("especiales")

    # 1. Registrar/actualizar cliente
    cliente_doc = clientes_coll.find_one({"nombre": nombre_cliente, "contacto": contacto})
    if cliente_doc:
        cliente_id = cliente_doc["_id"]
    else:
        nuevo_cliente = {
            "nombre": nombre_cliente,
            "contacto": contacto,
            "eventos": []  # lista vacía de eventos por ahora
        }
        res = clientes_coll.insert_one(nuevo_cliente)
        cliente_id = res.inserted_id

    # 2. Registrar evento
    nuevo_evento = {
        "cliente_id": cliente_id,
        "cliente_nombre": nombre_cliente,
        "fecha": fecha_evento,
        "numero_invitados": invitados,
        "tipo_menu": tipo_menu,
        "requerimientos_especiales": req_especiales,
        "personal_asignado": [],       # inicialmente ningún empleado asignado
        "ultima_actualizacion": datetime.now()
    }
    result = eventos_coll.insert_one(nuevo_evento)
    event_id = result.inserted_id

    # 3. Enlazar este evento con el cliente (añadir el evento a la lista del cliente)
    clientes_coll.update_one({"_id": cliente_id}, {"$push": {"eventos": event_id}})

    # 4. Mostrar confirmación al usuario con los detalles
    # Convertir ObjectId a string para mostrarlo (código de evento)
    event_id_str = str(event_id)
    return render_template("confirm.html", event_id=event_id_str, nombre=nombre_cliente, fecha=fecha_evento, invitados=invitados, menu=tipo_menu)

# Ruta 4: Formulario para buscar evento a actualizar (clientes)
@app.route("/actualizar", methods=["GET", "POST"])
def buscar_evento():
    if request.method == "POST":
        event_id_input = request.form.get("event_id")
        # Redirigir a la página de edición del evento específico
        return redirect(url_for("editar_evento", evento_id=event_id_input))
    # Si GET, mostrar formulario para introducir ID
    return render_template("find_event.html")

# Ruta 5: Mostrar formulario de edición de un evento específico
@app.route("/actualizar/<evento_id>", methods=["GET"])
def editar_evento(evento_id):
    # Buscar el evento por su ID
    try:
        evento = eventos_coll.find_one({"_id": ObjectId(evento_id)})
    except:
        evento = None
    if not evento:
        # Si no se encuentra, redirigir con un mensaje (a implementar) o mostrar error simple
        return render_template("find_event.html", error="No se encontró el evento con código proporcionado.")
    # Si se encontró, renderizar formulario con datos actuales
    return render_template("edit_event.html", evento=evento)

# Ruta 6: Procesar la actualización de evento (número de invitados u otros cambios)
@app.route("/guardar_evento/<evento_id>", methods=["POST"])
def guardar_evento(evento_id):
    nuevo_numero = int(request.form.get("invitados_nuevo"))
    # (Podríamos procesar otros campos si permitimos más cambios, pero en este caso solo número de invitados)
    eventos_coll.update_one(
        {"_id": ObjectId(evento_id)},
        {"$set": {"numero_invitados": nuevo_numero, "ultima_actualizacion": datetime.now()}}
    )
    # Registrar notificación de cambio en la colección de notifs (opcional)
    evento = eventos_coll.find_one({"_id": ObjectId(evento_id)})
    mensaje = f"Cambio: Evento {evento_id} ahora tiene {nuevo_numero} invitados."
    notifs_coll.insert_one({
        "evento_id": ObjectId(evento_id),
        "mensaje": mensaje,
        "fecha": datetime.now()
    })
    # Mostrar confirmación de actualización
    return render_template("confirm_update.html", evento=evento)

# Ruta 7: Página de administración - Lista de eventos y asignación de personal
@app.route("/eventos")
def administrar_eventos():
    # Obtener todos los eventos (podríamos filtrar solo futuros, etc.)
    eventos = list(eventos_coll.find({}))
    # Obtener todos los empleados para poder asignar
    empleados = list(empleados_coll.find({}))
    # Preparar un diccionario de empleados para referencia rápida por ID a nombre
    mapa_empleados = {str(emp["_id"]): emp["nombre"] for emp in empleados}
    # Convertir ObjectId a str y formatear datos para la plantilla
    for ev in eventos:
        ev["_id"] = str(ev["_id"])
        ev["ultima_actualizacion"] = ev.get("ultima_actualizacion", datetime.now()).strftime("%Y-%m-%d %H:%M")
        # Obtener nombres del personal ya asignado (si los hay)
        asignados = []
        for emp_id in ev.get("personal_asignado", []):
            emp_id_str = str(emp_id)
            if emp_id_str in mapa_empleados:
                asignados.append(mapa_empleados[emp_id_str])
            else:
                asignados.append(f"ID:{emp_id_str}")
        ev["nombres_asignados"] = ", ".join(asignados) if asignados else ""
    # Calcular algunos totales de ejemplo (e.g., total invitados en todos los eventos)
    total_eventos = len(eventos)
    total_invitados = sum(ev.get("numero_invitados", 0) for ev in eventos)
    return render_template("events.html", eventos=eventos, empleados=empleados, total_eventos=total_eventos, total_invitados=total_invitados)

# Ruta 8: Agregar empleado (desde página de empleados)
@app.route("/empleados", methods=["GET", "POST"])
def administrar_empleados():
    if request.method == "POST":
        nombre_emp = request.form.get("nombre")
        rol_emp = request.form.get("rol")
        nuevo_emp = {
            "nombre": nombre_emp,
            "rol": rol_emp,
            "eventos_asignados": []
        }
        empleados_coll.insert_one(nuevo_emp)
        return redirect(url_for("administrar_empleados"))
    else:
        empleados = list(empleados_coll.find({}))
        # Calcular número de asignaciones por empleado (tamaño de su lista eventos_asignados)
        for emp in empleados:
            emp["_id"] = str(emp["_id"])
            emp["num_eventos"] = len(emp.get("eventos_asignados", []))
        return render_template("employees.html", empleados=empleados)

# Ruta 9: Asignar empleado a evento (accion desde formulario en events.html)
@app.route("/asignar_personal", methods=["POST"])
def asignar_personal():
    evento_id = request.form.get("evento_id")
    empleado_id = request.form.get("empleado_id")
    if evento_id and empleado_id:
        eventos_coll.update_one(
            {"_id": ObjectId(evento_id)},
            {"$push": {"personal_asignado": ObjectId(empleado_id)}}
        )
        empleados_coll.update_one(
            {"_id": ObjectId(empleado_id)},
            {"$push": {"eventos_asignados": ObjectId(evento_id)}}
        )
    return redirect(url_for("administrar_eventos"))

# Iniciar servidor (modo desarrollo)
if __name__ == "__main__":
    app.run(debug=True)
